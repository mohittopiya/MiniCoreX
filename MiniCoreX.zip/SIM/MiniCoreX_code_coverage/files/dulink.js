var g_data = {"2":["work.MiniCoreX_design",89.86,1],"1":["work.MiniCoreX_tb",70.61,1]};
processDuLinks(g_data);