var g_data = {"4":[3,"dut",1],"3":[-1,"MiniCoreX_tb",1]};
processInstLinks(g_data);