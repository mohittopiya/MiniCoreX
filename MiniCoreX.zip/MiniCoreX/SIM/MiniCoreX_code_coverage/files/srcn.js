var g_data = ["","../TB/MiniCoreX_tb.v","../RTL/MiniCoreX_design.v"];
processSrcNamesData(g_data);